//
// Created by jhgri on 10/28/2019.
//
#include <iostream>
#include "Ray.h"

using namespace std;

Ray::Ray(const Eigen::Vector3d &lv, const Eigen::Vector3d &dv) : point(lv.normalized()), direct(dv.normalized()){}