//
// Created by jhgri on 10/28/2019.
//

#include "Object.h"

using namespace std;

Object::Object(const Eigen::Vector3d &w, double theta, double scale, const Eigen::Vector3d &t_xyz, const std::string &name) : w(w){
    t = makeTMatrix(t_xyz.x(), t_xyz.y(), t_xyz.z());
    s = makeSMatrix(scale);
    auto rw = makeRwMatrix(w.x(), w.y(), w.z());
    auto z = makeZMatrix(theta);
    r = makeBigRMatrix(z, rw);

    m = t * s * r;
    readInObj(name);
}

Eigen::MatrixXd Object::makeTMatrix(double tx, double ty, double tz){
    Eigen::MatrixXd matrix(4, 4);
    matrix << 1, 0, 0, tx,
            0, 1, 0, ty,
            0, 0, 1, tz,
            0, 0, 0, 1;
    return matrix;
}

Eigen::MatrixXd Object::makeSMatrix(double scale){
    Eigen::MatrixXd matrix(4, 4);
    matrix << scale, 0, 0, 0,
            0, scale, 0, 0,
            0, 0, scale, 0,
            0, 0, 0, 1;
    return matrix;
}

Eigen::Vector3d Object::makeMVec(double wx, double wy, double wz){
    if(wx >= wy && wy >= wz){
        wz = 1;
    } else if (wy >= wz && wz >= wx){
        wx = 1;
    } else{
        wy = 1;
    }
    Eigen::Vector3d m(wx, wy, wz);
    return m;
}

Eigen::MatrixXd Object::makeZMatrix(double theta){
    double radian = theta * PI / 180.0;
    double z00 = cos(radian);
    double z01 = -1 * sin(radian);
    double z10 = sin(radian);
    double z11 = cos(radian);

    Eigen::MatrixXd z(4,4);
    z << z00, z01, 0, 0,
            z10, z11, 0, 0,
            0, 0, 1, 0,
            0, 0, 0, 1;
    return z;
}

Eigen::MatrixXd Object::makeRwMatrix(double wx, double wy, double wz){
    Eigen::Vector3d w(wx,wy,wz);
    w = w.normalized();
    auto m = makeMVec(wx, wy, wz);
    auto u = m.cross(w);
    u = u.normalized();
    auto v = w.cross(u);

    Eigen::MatrixXd matrix(4,4);
    matrix << u.x(), u.y(), u.z(), 0,
            v.x(), v.y(), v.z(), 0,
            w.x(), w.y(), w.z(), 0,
            0,    0,      0,     1;
    return matrix;
}

Eigen::MatrixXd Object::makeBigRMatrix(const Eigen::MatrixXd &z, const Eigen::MatrixXd &rw){
    Eigen::MatrixXd rwTranspose(4,4);
    rwTranspose = rw.transpose();
    return rwTranspose * z * rw;
}

void Object::readMats(const string &filename){
    ifstream file((filename).c_str()); // Make sure the file path is correct on linux machines!!
    if(!file.good()) {
        cerr << filename << ": file does not exist!" << '\n';
        exit(1);
    }
    string line;
    string mat_name = "";
    double ns, x, y, z;
    Eigen::Vector3d ka,kd,ks;
    int illum = 0;
    while(getline(file, line)) {
        stringstream ss;
        string description;
        ss << line;
        ss >> description;
        if (description == "newmtl") {
            if(mat_name != "") {
                if (illum == 3) {
                    Material mat(ka, kd, ks, ks, mat_name, illum, ns);
                    mats.emplace_back(mat);
                } else {
                    Material mat(ka, kd, ks, Eigen::Vector3d(0, 0, 0), mat_name, illum, ns);
                    mats.emplace_back(mat);
                }
            }
            ss >> mat_name;
            cout << "name " << mat_name << "\n";
        } else if (description == "Ns") {
            ss >> ns;
        } else if (description == "Ka") {
            ss >> x >> y >> z;
            ka = Eigen::Vector3d(x, y, z);
        } else if (description == "Kd") {
            ss >> x >> y >> z;
            kd = Eigen::Vector3d(x, y, z);
        } else if (description == "Ks") {
            ss >> x >> y >> z;
            ks = Eigen::Vector3d(x, y, z);
        } else if (description == "illum") {
            ss >> illum;
        }
    }
    // for last mat
    if (illum == 3) {
        Material mat(ka, kd, ks, ks, mat_name, illum, ns);
        mats.emplace_back(mat);
    } else {
        Material mat(ka, kd, ks, Eigen::Vector3d(0, 0, 0), mat_name, illum, ns);
        mats.emplace_back(mat);
    }
}

void Object::readInObj(const string &obj_name){
    ifstream obj((obj_name).c_str()); // Make sure the file path is correct on linux machines!!
    if(!obj.good()) {
        cerr << obj_name << ": file does not exist!" << '\n';
        exit(1);
    }
    string line;
    int currMatIndex = 0;
    while(getline(obj, line)) {
        if(!(line[0] == 'v' && line[1] == 'n')) { // not a surface normal
            stringstream ss;
            string description;
            ss << line;
            ss >> description;
            if (description == "v") {
                double x, y, z;
                ss >> x >> y >> z;
                Eigen::Vector4d vec(x, y, z, 1);
                auto a = m * vec;
                Eigen::Vector3d vertex(vec.x(), vec.y(), vec.z());
                vertices.emplace_back(vertex);
            } else if (description == "mtllib") {
                string mat_filename;
                ss >> mat_filename;
                readMats(mat_filename);
            } else if (description == "usemtl"){
                string name;
                ss >> name;
                for(size_t i = 0; i < mats.size(); i++){
                    if(mats[i].descriptor == name){
                        currMatIndex = i;
                    }
                }
            } else if (description == "f") {
                int v1, v2, v3;
                string blah1, blah2, blah3;
                ss >> v1 >> blah1 >> v2 >> blah2 >> v3 >> blah3;
                vector<int> face = {v1, v2, v3, currMatIndex};
                faces.emplace_back(face);
            }
        }
    }
    obj.close();
    cout << "ended reading file" << "\n";
    /*cout << faces.size() << "\n";
    for(const auto &face : faces){
        cout << face[0] << " " << face[1] << " " << face[2] << " " << face[3]<< "\n";
    }
    for(const auto &mat : mats){
        cout << mat.descriptor << " " << mat.illum << " " << mat.ka << "\n\n" << mat.kd << "\n\n" << mat.kr << "\n\n" << mat.ks << "\n\n";
    }*/
    for(const auto &vert:vertices){
        cout << vert << "\n\n";
    }

    cout << "length " << vertices.size();
}

bool Object::checkIntersect(Ray &ray) const{
    const double EPSILON = 1 * pow(10, -5);
    for(const vector<int> &face : faces){
        auto a = vertices[face[0]-1];
        auto b = vertices[face[1]-1];
        auto c = vertices[face[2]-1];
        int mat_index = face[3];

        //cout << ray.point << "\n";
        //cout << "a\n" << b << "\n";
        Eigen::MatrixXd matrix(3,3);
        Eigen::Vector3d col1(a.x()-b.x(), a.y()-b.y(), a.z()-b.z());
        Eigen::Vector3d col2(a.x()-c.x(),a.y()-c.y(),a.z()-c.z());
        matrix << col1.x(), col2.x(), ray.direct.x(),
                  col1.y(), col2.y(), ray.direct.y(),
                  col1.z(), col2.z(), ray.direct.z();
        Eigen::Vector3d vec(a.x()-ray.point.x(), a.y()-ray.point.y(), a.z()-ray.point.z());
        Eigen::Vector3d byt = matrix.inverse() * vec;
        double beta = byt.x();
        double gamma = byt.y();
        double hit_dist = byt.z();
        //cout << byt << "\n\n";
        if(beta >= EPSILON && gamma >= EPSILON && (beta + gamma <= 1 - EPSILON) && hit_dist > EPSILON){
            if(ray.best_dist > hit_dist){
                //cout << "hit" << "\n";
                ray.best_dist = hit_dist;
                //cout << "ray.point:\n" << ray.point << "\n\nt:\n" << t << "\n\nray.direct:\n" << ray.direct;
                ray.best_point = ray.point + hit_dist * ray.direct;
                ray.mat = mats[mat_index];
                ray.surf_norm = col1.cross(col2);
                if(ray.direct.dot(ray.surf_norm) > 0){
                    ray.surf_norm *= -1;
                }
                return true;
            }
        }
    }
    return false;
}